package de.aittr.demo20240807;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo20240807Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo20240807Application.class, args);
	}

}
