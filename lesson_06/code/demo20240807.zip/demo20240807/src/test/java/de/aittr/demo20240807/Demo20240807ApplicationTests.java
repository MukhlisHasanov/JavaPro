package de.aittr.demo20240807;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo20240807ApplicationTests {

	@Test
	void contextLoads() {
	}

}
